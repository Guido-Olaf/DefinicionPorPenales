﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProyectoFinalDef
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ActualizarLista();
        }
        private void ActualizarLista()
        {
            if(File.Exists("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt") == true && File.Exists("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt") == true)
            {
                lstFactura.Items.Clear();
                FileStream Cabeza = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt", FileMode.Open);
                FileStream Detalle = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt", FileMode.Open);
                StreamReader LectorCabeza =new StreamReader(Cabeza);
                StreamReader LectorDetalle = new StreamReader(Detalle);

                string RegCabeza = "";
                string RegDetalle = "";
                String[] VectorCabeza = new string[0];
                String[] VectorDetalle = new string[0];

                lstFactura.Items.Add("--FACTURA-- --COD.ART.-- --DESCRIPCION-- --PRECIO-- --CANTIDAD--");
                lstFactura.Items.Add("---------------------------------------------------------------------------------------------------------------------------");


                while (LectorCabeza.Peek() >-1 && LectorDetalle.Peek() > -1)
                {
                    RegCabeza = LectorCabeza.ReadLine();
                    RegDetalle = LectorDetalle.ReadLine();
                    VectorCabeza = RegCabeza.Split(';');
                    VectorDetalle = RegDetalle.Split(';');

                    lstFactura.Items.Add(VectorCabeza[0] +" -- " + VectorCabeza[1] +" -- " + VectorCabeza[2] + " -- " + VectorDetalle[1] + " -- " + VectorDetalle[2]);
                }
                LectorDetalle.Close();
                LectorCabeza.Close();
                Detalle.Close();
                Cabeza.Close();

            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if(txtFactura.Text !="" && txtCodArticulo.Text !="" && txtDescripcion.Text !="" && txtCantidad.Text !="" && txtPrecio.Text != "")
            {
                FileStream Cabeza = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt", FileMode.Append);
                StreamWriter EscritorCabeza = new StreamWriter(Cabeza);
                FileStream Detalle = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt", FileMode.Append);
                StreamWriter EscritorDetalle = new StreamWriter(Detalle);

                string RegCabeza = "";
                string RegDetalle = "";
                String[] VectorCabeza = new string[0];
                String[] VectorDetalle = new string[0];

                RegCabeza = txtFactura.Text + ";" + txtCodArticulo.Text + ";" + txtDescripcion.Text;
                RegDetalle = txtFactura.Text + ";" + txtPrecio.Text + ";" + txtCantidad.Text;

                VectorCabeza = RegCabeza.Split(';');
                VectorDetalle = RegDetalle.Split(';');

                EscritorCabeza.WriteLine(RegCabeza);
                EscritorDetalle.WriteLine(RegDetalle);

                EscritorDetalle.Close();
                Detalle.Close();
                EscritorCabeza.Close();
                Cabeza.Close();

                ActualizarLista();

                txtCodArticulo.Text = "";
                txtDescripcion.Text = "";
                txtPrecio.Text = "";
                txtCantidad.Text = "";

                txtCodArticulo.Focus();


            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            FileStream Cabeza = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt", FileMode.Open);
            FileStream Detalle = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt", FileMode.Open);
            StreamReader LectorCabeza = new StreamReader(Cabeza);
            StreamReader LectorDetalle = new StreamReader(Detalle);

            FileStream CabezaTemp = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\CabezaTemp.txt", FileMode.Append);
            FileStream DetalleTemp = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\DetalleTemp.txt", FileMode.Append);
            StreamWriter EscritorCabezaTemp = new StreamWriter(CabezaTemp);
            StreamWriter EscritorDetalleTemp = new StreamWriter(DetalleTemp);

            string RegCabeza = "";
            string RegDetalle = "";
            String[] VectorCabeza = new string[0];
            String[] VectorDetalle = new string[0];

            while(LectorCabeza.Peek() >-1 && LectorDetalle.Peek() > -1)
            {
                RegCabeza = LectorCabeza.ReadLine();
                RegDetalle = LectorDetalle.ReadLine();

                VectorCabeza = RegCabeza.Split(';');
                VectorDetalle = RegDetalle.Split(';');

                if (VectorCabeza[0] != txtFactura.Text && VectorDetalle[0] != txtFactura.Text)
                {
                    EscritorCabezaTemp.WriteLine(RegCabeza);
                    EscritorDetalleTemp.WriteLine(RegDetalle);
                }

            }
            EscritorDetalleTemp.Close();
            EscritorCabezaTemp.Close();
            DetalleTemp.Close();
            CabezaTemp.Close();
            LectorDetalle.Close();
            LectorCabeza.Close();
            Detalle.Close();
            Cabeza.Close();


            File.Delete("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt");
            File.Delete("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt");

            File.Move("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\CabezaTemp.txt", "C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt");
            File.Move("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\DetalleTemp.txt", "C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt");

            ActualizarLista();

            txtFactura.Text = "";
            txtCodArticulo.Text = "";
            txtDescripcion.Text = "";
            txtPrecio.Text = "";
            txtCantidad.Text = "";
            txtFactura.Focus();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

            FileStream Cabeza = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt", FileMode.Open);
            FileStream Detalle = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt", FileMode.Open);
            StreamReader LectorCabeza = new StreamReader(Cabeza);
            StreamReader LectorDetalle = new StreamReader(Detalle);

            FileStream CabezaTemp = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\CabezaTemp.txt", FileMode.Append);
            FileStream DetalleTemp = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\DetalleTemp.txt", FileMode.Append);
            StreamWriter EscritorCabezaTemp = new StreamWriter(CabezaTemp);
            StreamWriter EscritorDetalleTemp = new StreamWriter(DetalleTemp);

            string RegCabeza = "";
            string RegDetalle = "";
            String[] VectorCabeza = new string[0];
            String[] VectorDetalle = new string[0];

            while (LectorCabeza.Peek() > -1 && LectorDetalle.Peek() > -1)
            {
                RegCabeza = LectorCabeza.ReadLine();
                RegDetalle = LectorDetalle.ReadLine();

                VectorCabeza = RegCabeza.Split(';');
                VectorDetalle = RegDetalle.Split(';');

              
                if (VectorDetalle[0] == txtFactura.Text && VectorCabeza[1] == txtCodArticulo.Text)
                {
                    RegCabeza = txtFactura.Text + ";" + txtCodArticulo.Text + ";" + txtDescripcion.Text;
                    RegDetalle = txtFactura.Text + ";" + txtPrecio.Text + ";" + txtCantidad.Text;

                    EscritorCabezaTemp.WriteLine(RegCabeza);
                    EscritorDetalleTemp.WriteLine(RegDetalle);
                }
                else
                { 
                    EscritorCabezaTemp.WriteLine(RegCabeza);
                    EscritorDetalleTemp.WriteLine(RegDetalle);
                }

            }
            EscritorDetalleTemp.Close();
            EscritorCabezaTemp.Close();
            DetalleTemp.Close();
            CabezaTemp.Close();
            LectorDetalle.Close();
            LectorCabeza.Close();
            Detalle.Close();
            Cabeza.Close();


            File.Delete("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt");
            File.Delete("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt");

            File.Move("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\CabezaTemp.txt", "C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt");
            File.Move("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\DetalleTemp.txt", "C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt");

            ActualizarLista();

            txtFactura.Text = "";
            txtCodArticulo.Text = "";
            txtDescripcion.Text = "";
            txtPrecio.Text = "";
            txtCantidad.Text = "";
            txtFactura.Focus();

        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            lstFactura.Items.Clear();
            lstFactura.Items.Add("-----------------------------------------------COMPROBANTES----------------------------------------------------------------------------");

            FileStream Cabeza = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Cabeza.txt", FileMode.Open);
            StreamReader LectorCabeza = new StreamReader(Cabeza);

            string RegCabeza = "";
            string RegDetalle = "";
            String[] VectorCabeza = new string[0];
            String[] VectorDetalle = new string[0];
            bool flag = false;
            Decimal Total = 0;


            while (LectorCabeza.Peek() > -1)
            {
                RegCabeza = LectorCabeza.ReadLine();
                VectorCabeza = RegCabeza.Split(';');
                FileStream Detalle = new FileStream("C:\\Users\\guido\\OneDrive\\Desktop\\Definicion Del Partido\\ProyectoFinalDef\\bin\\Debug\\Detalle.txt", FileMode.Open);
                StreamReader LectorDetalle = new StreamReader(Detalle);


                while (LectorDetalle.Peek() > -1)
                {
                    RegDetalle = LectorDetalle.ReadLine();
                    VectorDetalle = RegDetalle.Split(';');

                    if (VectorCabeza[0] == VectorDetalle[0] && flag == false)
                    {
                        Total += Convert.ToDecimal(VectorDetalle[1]) * Convert.ToDecimal(VectorDetalle[2]);
                    }
                    if (VectorCabeza[0] != VectorDetalle[0])
                    {
                        flag = true;
                    }
                    lstFactura.Items.Add("Cod. Articulo: " + VectorCabeza[1] + " Descripcion: " + VectorCabeza[2] + " Precio: " + VectorDetalle[1] + " Cantidad: " + VectorDetalle[2]);


                }
                lstFactura.Items.Add("FACTURA: " + VectorCabeza[0] + " TOTAL: " + Total);
                lstFactura.Items.Add("---------------------------------------------------------------------------------------------------------------------------");




                Total = 0;
                flag = false;
                LectorDetalle.Close();
                Detalle.Close();

            }

            LectorCabeza.Close();
            Cabeza.Close();


        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            ActualizarLista();
        }
    }
}
